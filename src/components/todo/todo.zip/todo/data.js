const list = [
  {
    id: 1,
    title: "Work",
    done: true,
  },
  {
    id: 2,
    title: "Sport",
    done: false,
  },
  {
    id: 3,
    title: "Shopping",
    done: false,
  },
];

export default list;
